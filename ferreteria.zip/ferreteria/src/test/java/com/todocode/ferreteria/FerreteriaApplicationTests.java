package com.todocode.ferreteria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FerreteriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
